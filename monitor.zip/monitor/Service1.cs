﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using NPOI.XSSF.UserModel;


namespace monitor
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        //创建制程资料库的连接对象变量
        private static string connStr = "Data Source=140.137.41.136,3604;Initial Catalog=ExcelData;User ID=sa;Password=Tower#0309";

        //创建信息资料库的连接对象变量
        private static string MsconnStr = "Data Source=140.137.41.136,3604;Initial Catalog=ExcelMassage;User ID=sa;Password=Tower#0309";

        //系统上Log档案文件路径
        private static string path = @"D:\Monitored_Folder_Log\Log.txt";

        //发送邮件的函数
        public static void SendMail(string Body, string name)
        {
            //创建邮件验证信息
            string FromMial = "554317150@qq.com";
            string ToMial = "15859788098m@sina.cn";
            string AuthorizationCode = "bnayfsfzrjbabbdb";

            //设置一个系统时间
            string Stime = DateTime.Now.ToString();
            try
            {
                //实例化一个发送邮件类。
                MailMessage mailMessage = new MailMessage();

                //邮件的优先级，分为 Low, Normal, High，通常用 Normal即可
                mailMessage.Priority = MailPriority.Normal;

                //发件人邮箱地址。
                mailMessage.From = new MailAddress(FromMial);

                //收件人邮箱地址。需要群发就写多个
                //拆分邮箱地址
              //List<string> ToMiallist = ToMial.Split(';').ToList();
               // for (int i = 0; i < ToMiallist.Count; i++)
               // {
                    mailMessage.To.Add(new MailAddress(ToMial));  //收件人邮箱地址。
               // }

                //如果你的邮件标题包含中文，这里一定要指定，否则对方收到的极有可能是乱码。
                mailMessage.SubjectEncoding = Encoding.GetEncoding(936);

                //邮件正文是否是HTML格式
                mailMessage.IsBodyHtml = false;

                //邮件标题。
                mailMessage.Subject = Stime + ":" + name + "制程资料错误讯息";
                //邮件内容。
                mailMessage.Body = Body;

                //实例化一个SmtpClient类。
                SmtpClient client = new SmtpClient();

                //设置邮件服务器地址
                client.Host = "smtp.qq.com";

                //使用安全加密连接。
                client.EnableSsl = true;
                //不和请求一块发送。
                client.UseDefaultCredentials = false;

                //验证发件人身份(发件人的邮箱，邮箱里的生成授权码);
                client.Credentials = new System.Net.NetworkCredential(FromMial, AuthorizationCode);

                //如果发送失败，SMTP 服务器将发送 失败邮件告诉我  
                mailMessage.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                //发送
                client.Send(mailMessage);
                File.AppendAllText(path, Environment.NewLine + Stime + ":   侦测到" + name + "制程资料错误，已发送错误资讯邮件");
                ExcelLogDb(Stime + ":   侦测到" + name + "制程资料错误，已发送错误资讯邮件");
            }
            catch (Exception)
            {
                File.AppendAllText(path, Environment.NewLine + Stime + ":   侦测到" + name + "制程资料错误，但是邮件发送失败!!!");
                ExcelLogDb(Stime + ":   侦测到" + name + "制程资料错误，但是邮件发送失败!!!");
            }
        }

        public static void ExcelJJ(double t, double x, double y, double z)
        {
            String strSQL = " INSERT INTO ExcelJJ (Xs, RealX, RealY, RealZ) VALUES (" + t + "," + x + "," + y + "," + z + ")";
            SqlConnection sqlConn = new SqlConnection(MsconnStr);  //创建连接信息资料库
            sqlConn.Open();
            SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
            sqlcommand.ExecuteNonQuery();
            sqlConn.Close();
        }

        public static void ExcelLogDb(string TLog)
        {
            String strSQL = " INSERT INTO ExcelTLog (TLog) VALUES (N'" + TLog + "')";
            SqlConnection sqlConn = new SqlConnection(MsconnStr);  //创建连接信息资料库
            sqlConn.Open();
            SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
            sqlcommand.ExecuteNonQuery();
            sqlConn.Close();
        }

        public static void ExcelCheckDb(string TName, string TCheck)
        {
            String strSQL = " INSERT INTO ExcelTCheck (TName, TCheck) VALUES ( '" + TName + " '," + "N'" + TCheck + "' )";
            SqlConnection sqlConn = new SqlConnection(MsconnStr);  //创建连接信息资料库
            sqlConn.Open();
            SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
            sqlcommand.ExecuteNonQuery();
            sqlConn.Close();
        }

        public static void CreateDataTable(string db, string tb)
        {
            string STime = DateTime.Now.ToString();   //調整該函數内的時間記錄

            string content = " Xs float ,RealX float ,RealY float ,RealZ float ,Id int identity(1,1) PRIMARY KEY";
            string createTableStr = "USE " + db + " Create table " + tb + "(" + content + ")";

            SqlConnection connection = new SqlConnection(connStr);//创建连接制程资料库

            SqlCommand sqlCommand = new SqlCommand(createTableStr);

            sqlCommand.Connection = connection;

            connection.Open();//打开连接
            sqlCommand.ExecuteReader();
            connection.Close();//关闭连接
 

            File.AppendAllText(path, Environment.NewLine + STime + ":   已在" + db +"资料库成功建立" + tb + "新资料表");
            //ExcelLogDb(STime + ":   已在" + db + "资料库成功建立" + tb + "新资料表");

            //将信息写入 信息资料表里面
            
            String strSQL = " INSERT INTO ExcelTCreate (TName, TTime) VALUES ('" + tb + "', '" + STime + "')";
            SqlConnection sqlConn = new SqlConnection(MsconnStr);  //创建连接信息资料库
            sqlConn.Open();
            SqlCommand sqlcommand = new SqlCommand(strSQL, sqlConn);
            sqlcommand.ExecuteNonQuery();
            sqlConn.Close();
            
        }

        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            //Console.WriteLine("檔案變更: " + e.FullPath + "名字：" + e.Name + "  " + e.ChangeType);

            string STime1 = DateTime.Now.ToString();   //調整該函數内的第一个時間記錄
            File.AppendAllText(path, Environment.NewLine + STime1 + ":   监控到新资料，档名为：" + e.Name);
            ExcelLogDb(STime1 + ":   监控到新资料，档名为：" + e.Name);

            string[] sname = e.Name.Split('.');
            string name = sname[0];

            ExcelLogDb(STime1 + ":   已在资料库成功建立" + name + "新资料表");

            var ExcelTable = new DataTable();

            CreateDataTable("ExcelData", name);

            //错误资讯信息
            string SunCheckData = "";
            Boolean Correct = true;//利用布林值来判断是否出错

            var Adp = new SqlDataAdapter("select * from " + name, connStr);
            var DataCopier = new SqlBulkCopy(connStr) { DestinationTableName = name };
            Adp.FillSchema(ExcelTable, SchemaType.Source);

            var WorkBook = new XSSFWorkbook(File.OpenRead(@e.FullPath));
            var st = WorkBook.GetSheetAt(0); //第一个表

            double tt = 0.1;  //时间区间
            int tnumber = 0;  //每个0.1s内几笔
            double sumX = 0;  //X轴力总
            double sumY = 0;  //Y轴力总
            double sumZ = 0;  //Z轴力总


            for (var RowIndex = 2; RowIndex <= st.LastRowNum; RowIndex++)
            {
                var TableNewRow = ExcelTable.NewRow();
                var TempRow = st.GetRow(RowIndex);

                TableNewRow[0] = TempRow.Cells[0].NumericCellValue;
                TableNewRow[1] = TempRow.Cells[1].NumericCellValue;  //X轴
                TableNewRow[2] = TempRow.Cells[2].NumericCellValue;  //Y轴
                TableNewRow[3] = TempRow.Cells[3].NumericCellValue;  //Z轴

                sumX += TempRow.Cells[1].NumericCellValue;
                sumZ += TempRow.Cells[3].NumericCellValue;
                sumY += TempRow.Cells[2].NumericCellValue;
                
                tnumber += 1;

                if (TempRow.Cells[0].NumericCellValue >= tt)
                {
                    
                    if (Math.Abs((sumZ / tnumber)) > 1)
                        sumZ /= 10;

                    ExcelJJ(Math.Round(tt, 2), (sumX/tnumber), (sumY/tnumber), (sumZ/tnumber));
                    
                    tt += 0.1;
                    sumX = 0; sumY = 0; sumZ = 0;  //清零
                    tnumber = 0;     
                }
                /*
                if (TempRow.Cells[1].NumericCellValue == 5.55)
                {
                    string CheckData = "资料表在时间为" + TempRow.Cells[0].NumericCellValue + "Z轴的力产生极端值，刀片发生断裂";
                    SunCheckData += CheckData + Environment.NewLine;
                    Correct = false;
                    ExcelCheckDb(name, CheckData);

                }
                */
               
                if (TempRow.Cells[3].NumericCellValue >= 20)
                {
                    //string CheckData = "资料表在时间为" + TempRow.Cells[0].NumericCellValue + "时发生资料错误，累计长时间处于低切削值，机台发生停机故障";
                    //SunCheckData += CheckData + Environment.NewLine;
                    Correct = false;
                    //ExcelCheckDb(name, CheckData);
                }
                

                ExcelTable.Rows.Add(TableNewRow);
            }

            DataCopier.WriteToServer(ExcelTable);

            //Console.WriteLine("Data copy completed.");
            string STime2 = DateTime.Now.ToString();   //調整該函數内的第二个時間記錄
            File.AppendAllText(path, Environment.NewLine + STime2 + ":   " + e.Name + "资料上传成功");
            ExcelLogDb(STime2 + ":   " + e.Name + "资料上传成功");

            if (Correct == true)
            {
                string CheckData = "资料表无任何错误";
                //SendMail("资料表无任何错误", name);
                ExcelCheckDb(name, CheckData);
               File.AppendAllText(path, Environment.NewLine + STime2 + ":   资料表" + name + "无任何错误");
            }
            else
            {
                SendMail("资料表X,Y,Z轴的力产生极端值，判断刀片发生断裂", name);
                ExcelCheckDb(name, "资料表发生资料错误，资料表X,Y,Z轴的力产生极端值，判断刀片发生断裂");
                File.AppendAllText(path, Environment.NewLine + STime2 + ":   资料表" + name + "有发现错误，错误讯息邮件发送成功");
            }

        }

        protected override void OnStart(string[] args)
        {
            string StartTime = DateTime.Now.ToString();   //調整該函數内的時間記錄
            string StartTimeMS = StartTime + ":   微鑽製程监控服务启动";
            File.AppendAllText(path, Environment.NewLine + StartTimeMS);
            ExcelLogDb(StartTimeMS);

            var watcher = new FileSystemWatcher
            {
                // 設定要監看的資料夾
                Path = @"D:\Monitored_Folder",
                // 設定要監看的變更類型，這裡設定監看最後修改時間與修改檔名的變更事件
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName,
                // 設定要監看的檔案類型
                Filter = "*.xlsx",
                // 設定是否監看子資料夾
                IncludeSubdirectories = false,
                // 設定是否啟動元件，必須要設定為 true，否則監看事件是不會被觸發
                EnableRaisingEvents = true
            };

            watcher.Created += new FileSystemEventHandler(OnChanged);
            Console.ReadLine();  //千萬不能刪
            watcher.EndInit();
        }

        protected override void OnStop()
        {
            string STime = DateTime.Now.ToString();   //調整該函數内的時間記錄
            File.AppendAllText(path, Environment.NewLine + STime + ":   微鑽製程监控服务停止");
            ExcelLogDb(STime + ":   微鑽製程监控服务停止");

        }
    }
}
