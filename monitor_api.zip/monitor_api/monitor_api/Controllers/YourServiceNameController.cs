﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Diagnostics;

namespace monitor_api.Controllers
{
    public class YourServiceNameController : ApiController
    {   
        [Route("api/monitor/ConJJ/{num}")]
        [HttpGet]
        
        public IHttpActionResult ConJJ(int num)
        {
            Process p = new Process();
            String str = null;

            p.StartInfo.FileName = "cmd.exe";

            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.CreateNoWindow = true; //不跳出cmd視窗

            if(num == 2147483647)   //start windowsService
            {
                p.Start();
                p.StandardInput.WriteLine("net start YourServiceName");
                p.StandardInput.WriteLine("exit");

                str = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
                p.Close();

                Console.WriteLine(str);
                Console.ReadKey();

                return Ok("start success");
            }

            if(num == 0)   //stop windowsService
            {
                p.Start();
                p.StandardInput.WriteLine("net stop YourServiceName");
                p.StandardInput.WriteLine("exit");

                str = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
                p.Close();

                Console.WriteLine(str);
                Console.ReadKey();

                return Ok("stop successs");
            }

            return Ok("NONONO");
        }
    }
}
